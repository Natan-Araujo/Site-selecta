# Selecta

Plataforma gamificada de recrutamento — projeto educacional / portfólio.

## Como rodar (resumo)

**Backend**

```bash
cd backend
npm install
npm run dev
```

**Frontend**

```bash
cd frontend
npm install
npm run dev
```

Abra http://localhost:5173 e certifique-se que o backend está em http://localhost:4000.
