import React from 'react'

export default function Landing(){
  return (
    <header className="landing">
      <h1>Selecta</h1>
      <p>Plataforma gamificada de recrutamento — publique vagas e avalie candidatos por desafios.</p>
    </header>
  )
}
